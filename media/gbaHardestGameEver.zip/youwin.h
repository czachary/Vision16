#ifndef YOUWIN_BITMAP_H
#define YOUWIN_BITMAP_H
extern const unsigned short youwin[38400];
#define YOUWIN_WIDTH 240
#define YOUWIN_HEIGHT 160
#endif