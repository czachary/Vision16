#ifndef FINISH_BITMAP_H
#define FINISH_BITMAP_H
extern const unsigned short finish[900];
#define FINISH_WIDTH 30
#define FINISH_HEIGHT 30
#endif