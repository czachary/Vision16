
Christina Zachary


THE HARDEST GAME EVER
---------------------

This version of the game differs from the traditional Hardest Game Ever as there is only 1 level, and the player has 3 lives.

PURPOSE: You are the red square. Avoid the blue squares and make it to the finish line before you run out of lives!

INSTRUCTIONS: You can move up, down, left, or right through the three sets of enemies.
	Any contact with the blue squares will cause you to lose a life and be sent back to the beginning of the level.
	Pressing SELECT at any time will send you back to the title screen and reset your lives.
	Once you arrive at either the "game over" or "you win" screen, you can press SELECT to go back to the title screen.
	There is a "Lives" indicator in the upper right during game play, this text will turn to red when you have one life left.